Apache Cassandra User-Defined-Functions JSR 223 scripting
=========================================================

Unfortunately Jaskell JSR-223 support is quite old and the Jaskell engine seems to be quite
unsupported. If you find a solution, please open a ticket at Apache Cassandra JIRA.
